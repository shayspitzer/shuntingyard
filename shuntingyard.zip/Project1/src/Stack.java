/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

public interface Stack<AnyType> { // basic interface for stack
	public boolean isEmpty();
	public void push(AnyType x);
	public AnyType pop();
	public AnyType peek();

}
