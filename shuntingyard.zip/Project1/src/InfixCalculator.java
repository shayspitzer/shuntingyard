/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Scanner;

public class InfixCalculator { // contains main, run this with command line args 
	
	public static void main(String[] args) {
		String input = args[0]; // process command line arguments 
		String output = args[1];

		try {
			Scanner s = new Scanner(Paths.get(input)); // use scanner to read from file 
			FileWriter writer = new FileWriter(); // instantiate writer 
			writer.createFile(output); // create file 
			 while (s.hasNext()) {
				String exp = s.nextLine(); // read each line of text file 
				InfixSolver solver = new InfixSolver(exp); // instantiate solver to solve each expression 
				solver.parse(); // parse and convert 
				solver.solvePostFix(); // solve 
				double x = Double.parseDouble(solver.getSol()); // get solution from stack
				if (s.hasNextLine()) { // check if newline should be added after solution
				writer.addNum(x); // write solution to output file 
				}
				else {
					writer.addLastNum(x);
				}
				
				
				
			 }
			 writer.close(); // close FileWriter
			
		} catch (IOException e) { // handle IOException when initializing scanner 
			
			e.printStackTrace();
		}

	}
	
}
	
	
	
	
	
	
