/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

import java.io.FileNotFoundException;
import java.util.Formatter;

public class FileWriter { // creates, writes to, and closes file using Formatter
	
	private Formatter output;
	
	public void createFile(String name) {
		try { 
			output = new Formatter(name);
			
		}catch (FileNotFoundException e) {
			System.out.println("File not found.");
		}
	}
	
	public void addNum(double x) { // add a number to text file with two decimal places and a new line 
		output.format("%.2f%n", x);	
	}
	
	public void addLastNum(double x) { // add last number to text file without new line 
		output.format("%.2f", x);
	}
	
	public void close() { // close file
		output.close();
	}

}
