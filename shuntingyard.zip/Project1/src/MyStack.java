/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

public class MyStack<AnyType> implements Stack<AnyType> {  // my linked list/stack implementation w/ nested node class
	                                                       // based on Sedgewick p. 149
	public Node first;
	
	private class Node {
		AnyType item;
		Node next;
	}
	
	public boolean isEmpty() {
		return first == null;
	}

	
	public void push(AnyType x) {
		
		Node newNode = new Node();
		newNode.item = x;
		newNode.next = first;
		first = newNode;
	}

	public AnyType pop() {
		
		AnyType item = first.item;
		first = first.next;
		return item;
	}

	
	public AnyType peek() {
		return first.item;
	}

	public void printList() { 
		System.out.print("{");
		Node current = first;
		while (current != null) {
			System.out.print(current.item.toString() + ", ");
			current = current.next;
		}
		System.out.print("}\n");
	}
}
