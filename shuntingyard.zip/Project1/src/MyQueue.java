/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

public class MyQueue<AnyType> implements Queue<AnyType> {  // my linked list/queue implementation w/ nested node class
	                     						           // based on Sedgewick p. 151
	private Node first;
	private Node last;
	
	private class Node {
		AnyType item;
		Node next;
	}

	public boolean isEmpty() {
		
		if (first == null) 
			return true;
		
		else 
			return false;
	}

	public void enqueue(AnyType item) {
		Node oldLast = last;
		last = new Node();
		last.item = item;
		last.next = null;
		if (isEmpty())
			first = last;
		else 
			oldLast.next = last;	
	}

	public AnyType dequeue() {
		AnyType item = first.item;
		first = first.next;
		if (isEmpty())
			last = null;
		return item;
	}
	
	public void printList() { 
		System.out.print("{");
		Node current = first;
		while (current != null) {
			System.out.print(current.item.toString() + ", ");
			current = current.next;
		}
		System.out.print("}\n");
	}
}
