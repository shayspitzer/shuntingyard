/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

public interface Queue<AnyType> {  // basic interface for queue
	public boolean isEmpty();
	public void enqueue(AnyType item);
	public AnyType dequeue();

}
