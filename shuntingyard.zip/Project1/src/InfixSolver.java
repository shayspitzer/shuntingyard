/*
 * Shay Spitzer
 * sspitze2@u.rochester.edu
 */

public class InfixSolver {   // contains methods to parse infix equations, convert to postfix, and solve
	private MyStack<String> s1; // stack used to conversion/solving
	private MyQueue<String> q1; // queue used to conversion/solving
	private String infix;       // single equation in infix notation
	
	public InfixSolver(String s) {
		s1 = new MyStack<String>();
		q1 = new MyQueue<String>();
		this.infix = s;
	
	}
	
	public void parse() { // parses infix equation into 'tokens', see README for more
		int i = 0;
		while (i < infix.length()) {
			char c = infix.charAt(i); // examine each character in string
			if (Character.isDigit(c)) { // need special handling for numbers, as they could be decimals or multiple digits
				try {
					String num = Character.toString(c);
					for (int j = 1; i + j < infix.length(); j++) {
					    char ch = infix.charAt(i + j); // check next character after number 
					    
					    if (Character.toString(ch).equals(" ")) { //stop checking if space is found, number is complete
					    	break;
					    }
					    if (Character.isDigit(ch)) {
						    num += Character.toString(ch); // use string concatenation to add any additional digits
					} else if (Character.toString(ch).equals(".")) {
						    num += Character.toString(ch); // use string concatenation to add any decimal points
					}    
					}
					
					toPostFix(num); // call toPostFix() (see README/comments below) on entire new number comprised of decimals and digits
					i += num.length(); // skip to the end of the number
					continue;
					
				} catch (IndexOutOfBoundsException e) { // some error handling for numbers at the end of the string
					System.out.println("ERROR");
					toPostFix(Character.toString(c));	
				}
				
			} else if (Character.isLetter(c)) { // check for sin, cos, tan, cheating a little bit by assuming valid input and only using first letter
				if (Character.toString(c).equals("s")) { 
					toPostFix("sin"); // call toPostFix() on trig operator
					i += 2;
				} else if (Character.toString(c).equals("c")) {
					toPostFix("cos");
					i += 2;
				} else if (Character.toString(c).equals("t")) {
					toPostFix("tan");
					i += 2;
				}
				
			} else if (Character.toString(c).equals(" ")) { // ignore spaces 
				;
			} else {
				toPostFix(Character.toString(c)); // call toPostFix on every other character
			}
			
			i++;
		}
		
		while (!s1.isEmpty()) { // end of input, pop everything/enqueue
			String item = s1.pop();
			q1.enqueue(item);
		}	
	}
	
    public void toPostFix(String s) { // places each token in its appropriate place in the stack or queue
		
	    if (isDouble(s)) { // enqueue operands
			q1.enqueue(s);
	    } else if (s.equals(")")) { // pop tokens until left parenthesis is found, enqueue everything (except parentheses)
			while (!s1.isEmpty()) {
				String op = s1.pop();
				if (op.equals("(")) {
					break;
				}
				q1.enqueue(op);	
			}	
		} else if (s.equals("(")) { // push left parentheses to stack
			s1.push(s);
			
		} else if (s.equals(" ")) { // ignore spaces in case any decided to sneak in 
			;
		} else { // (hopefully) all other tokens are operators and can be handled with a single loop
			while (!s1.isEmpty())  { // pop tokens until operator of lower precedence, right-associative operator, or left parenthesis 
				if (getPrecedence(s1.peek()) < getPrecedence(s) ) {
					break;
				} else if (getPrecedence(s1.peek()) == getPrecedence(s) && getAssociativity(s1.peek()) == 1) {
					break;
				} else if (s1.peek().equals("(")) {
					break;
				}
				
				String op = s1.pop();
				q1.enqueue(op);	// enqueue all
			}
			s1.push(s);	
		}	
	}
	
	public boolean isDouble(String s) { // checks if a token is a double
		try  {
			Double.parseDouble(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
			
		}	
	}
	
	public int getPrecedence(String s) { // returns precedence of operator
		int p = 0;
		if (s.equals("^")) {
			p = 4;
		} else if ( s.equals("sin") || s.equals("cos") || s.equals("tan")) { // I wasn't sure where trig operators fit in to all of this
			p = 5;                                                           // but this has worked so far
		} else if (s.equals("*") || s.equals("/") || s.equals("%") ) {
			p = 3;
		} else if (s.equals("+") || s.equals("-")) {
			p = 2;
		} else if (s.equals("!") || s.equals("&")) {
			p = 1;
		} else if (s.equals(">") || s.equals("<") || s.equals("=")) {
			p = 0;
		}
		
		return p;
	}
	
	public int getAssociativity(String s) { // returns operator associativity (0 for left, 1 for right)
		int p = 0;
		if (s.equals("!") || s.equals("^") || s.equals("sin") || s.equals("cos") || s.equals("tan")) {
			 p = 1;
		}
		
		return p;
	}
	
	public void solvePostFix() { // evaluates postfix expression, with if/else blocks for each operator
		while (!q1.isEmpty()) {
			String s = q1.dequeue(); // dequeue each token 
			
			if (isDouble(s)) { // push to stack if operand
				s1.push(s);
			} else if (s.equals("!")) { // solve operations with logical not, push answer
				String num = s1.pop();
				double dnum = evalNot(num);
				String myString = String.valueOf(dnum);
				s1.push(myString);
			} else if (s.equals("sin") || s.equals("cos") || s.equals("tan")) { // solve trig operations, push answer
				String number = s1.pop();
				double dnumber = evalTrig(s, number);
				String myString1 = String.valueOf(dnumber);
				s1.push(myString1);
				
			} else { // all other operators require two operands, so we pop two from the stack 
		    	 double sol = 0;
		    	 double num2 = Double.parseDouble(s1.pop());
			     double num1 = Double.parseDouble(s1.pop());
			     
			     if (s.equals("+")) {  // solve respective operations, using 1.00 for true and 0.00 for false w/ logical operators
			    	 sol = num1 + num2;	 
			     } else if (s.equals("-")) {
			    	 sol = num1 - num2;
			     } else if (s.equals("*")) {
			    	 sol = num1 * num2;
			     } else if (s.equals("/")) {
			    	 sol = num1 / num2;	 
			     } else if (s.equals(">")) {
			    	 if (num1 > num2) {
			    		 sol = 1.00;
			    	 } else {
			    		 sol = 0.00;
			    	 }	 
			     } else if (s.equals("<")) {
			    	 if (num1 < num2) {
			    		 sol = 1.00;
			    	 } else {
			    		 sol = 0.00;
			    	 }	 
			     } else if (s.equals("=")) {
			    	 if (num1 == num2) {
			    		 sol = 1.00;
			    	 } else {
			    		 sol = 0.00;
			    	 }
			    		 
			     } else if (s.equals("|")) {
			    	 if (num1 == 1.00 || num2 == 1.00) {
			    		 sol = 1.00;
			    	 } else {
			    		 sol = 0.00;
			    	 }
			    		 
			     } else if (s.equals("&")) {
			    	 if (num1 == 1.00 && num2 == 1.00) {
			    		 sol = 1.00;
			    	 } else {
			    		 sol = 0.00;
			    	 }
			    		 
			     } else if (s.equals("%")) {
			    	 sol = num1 % num2;
			     } else if (s.equals("^")) {
			    	 sol = Math.pow(num1, num2);
			     }
			     
			     s1.push(String.valueOf(sol)); // push answer
			}
		}
		}
	
	public double evalNot(String s) { // evaluates operations with logical not, seemed easier to make a separate method
		double num = Double.parseDouble(s);
		
		if (num == 1.00) {
			return 0.00;
		} else 
			return 1.00;
	}
	
	public double evalTrig(String op, String s) { // solves trig operations
		double num = Double.parseDouble(s);
		double sol = 0.00;
		if (op.equals("sin")) {
			sol = Math.sin(num);
		} else if (op.equals("cos")) {
			sol = Math.cos(num);
		} else if (op.equals("tan")) {
			sol = Math.tan(num);
		}
		
		return sol;
	}
	
	public void printStack() { // use printList() method from MyStack to print all tokens
		s1.printList();
	}
	
	public void printQueue() { // use printList() method from MyQueue to print all tokens
		q1.printList();
	}
	
	public String getSol() { // returns first item in stack, used at the end when stack only contains solution
		return s1.peek();
	}

}
